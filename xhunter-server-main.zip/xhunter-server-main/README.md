# xhunter-server

xhunter-server is used to communicate between attacker and victim. It is very easy to host on [heroku](https://www.heroku.com/). follow the below steps:

#### Setup
- Signup and create a heroku account [here](https://signup.heroku.com)
- After login, click the below **Deploy** button.

   [![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/anirudhmalik/xhunter-server)
 
 - Give your app a name `<your_app_name>` and click `Deploy app` button.
 - Wait for the process to complete. 
 - Once complete, Click `view app` and If you see `Welcome to Xhunter Backend Server!!` then you have successfully created your server.
 - Now use this url `https://<your_app_name>.herokuapp.com` in [xhunter_v1.6.apk](https://github.com/anirudhmalik/xhunter/releases/tag/v1.6). during building payload and listening connection.
